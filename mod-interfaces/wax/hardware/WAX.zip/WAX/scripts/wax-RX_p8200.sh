#!/bin/bash
#cd ~/Dropbox/MachineLearningPlayground/MaxMspPatches/hardware/WAX/waxrec/
~/Dropbox/SID-Workshops/MaxMSP/hardware/WAX/waxrec/waxrec /dev/tty.usbmodem* -osc localhost:8200



